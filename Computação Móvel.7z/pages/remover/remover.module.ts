import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RemoverPage } from './remover';

@NgModule({
  declarations: [
    RemoverPage,
  ],
  imports: [
    IonicPageModule.forChild(RemoverPage),
  ],
})
export class RemoverPageModule {}
