import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, AlertController } from 'ionic-angular';

/**
 * Generated class for the PerfilPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-perfil',
  templateUrl: 'perfil.html',
})
export class PerfilPage {

  nova_senha: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController, public alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PerfilPage');
  }

  irCadastrar() {
    this.navCtrl.push("CadastrarPage");
  }

  irEditar() {
    this.navCtrl.push("EditarPage");
  }

  irRemover() {
    this.navCtrl.push("RemoverPage");
  }

  irVoltar() {
    this.navCtrl.pop();
  }

  abrirModal() {
    var modal = this.modalCtrl.create("TestePage");
    modal.present();
    modal.onDidDismiss(retorno => {
      this.nova_senha = retorno.nova_senha;
      console.log(this.nova_senha)});
      this.apresentarAlert();
  }

  apresentarAlert() {
    let alert = this.alertCtrl.create({
      title: 'Senha alterada!',
      subTitle: 'Nova Senha: ' + this.nova_senha,
      buttons: ['OK']
    });
    alert.present();
  }

  alterarSenhaAlert() {
    let alert = this.alertCtrl.create({
      title: 'ALTERAR SENHA',
      subTitle: 'Digite a nova senha.',
      inputs: [{
        name: 'password',
        placeholder: 'Password',
        type: 'password'
      }],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Alterar',
          handler: data => {
            this.nova_senha = data.password;
            console.log(this.nova_senha);
            this.apresentarAlert();
          }
        }
      ]
    });
    alert.present();
  }

}
